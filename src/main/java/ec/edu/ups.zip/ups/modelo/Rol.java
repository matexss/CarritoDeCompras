package ec.edu.ups.modelo;

public enum Rol {
    ADMINISTRADOR,
    USUARIO,
    CLIENTE
}