package ec.edu.ups.controlador;

import ec.edu.ups.modelo.servicio.CarritoServiceImpl;
import ec.edu.ups.modelo.Carrito;
import ec.edu.ups.modelo.ItemCarrito;
import ec.edu.ups.modelo.Producto;
import ec.edu.ups.modelo.Rol;
import ec.edu.ups.modelo.Usuario;
import ec.edu.ups.modelo.servicio.CarritoService;
import ec.edu.ups.dao.CarritoDAO;
import ec.edu.ups.dao.ProductoDAO;
import java.util.ArrayList;

import java.util.List;

public class CarritoController {

    private final CarritoService carritoService;
    private final CarritoDAO carritoDAO;
    private final ProductoDAO productoDAO;
    private final UsuarioController usuarioController;
    private final List<ItemCarrito> itemsTemporales = new ArrayList<>();


    public CarritoController(CarritoDAO carritoDAO, ProductoDAO productoDAO, UsuarioController usuarioController) {
        this.carritoDAO = carritoDAO;
        this.productoDAO = productoDAO;
        this.usuarioController = usuarioController;
        this.carritoService = new CarritoServiceImpl();
    }

    // Agregar producto al carrito temporal
    public void agregarProducto(Producto producto, int cantidad) {
        for (ItemCarrito item : itemsTemporales) {
            if (item.getProducto().getCodigo() == producto.getCodigo()) {
                item.setCantidad(item.getCantidad() + cantidad); // 🔁 suma cantidad
                return;
            }
        }
        // Si no existe, se agrega nuevo
        itemsTemporales.add(new ItemCarrito(producto, cantidad));
    }

    // Eliminar producto del carrito temporal
    public void eliminarProducto(int codigoProducto) {
        carritoService.eliminarProducto(codigoProducto);
    }

    // Vaciar carrito temporal
    public void vaciarCarrito() {
        carritoService.vaciarCarrito();
    }

    // Calcular total (subtotal + IVA)
    public double calcularTotal() {
        return carritoService.calcularTotal();
    }

    // Obtener ítems del carrito temporal
    public List<ItemCarrito> obtenerItems() {
        return carritoService.obtenerItems();
    }

    // Verificar si el carrito está vacío
    public boolean estaVacio() {
        return carritoService.estaVacio();
    }

    // Guardar el carrito actual como definitivo
    public void guardarCarrito(Carrito carrito) {
        for (ItemCarrito item : itemsTemporales) {
            carrito.agregarProducto(item.getProducto(), item.getCantidad());
        }
        carrito.setUsuario(usuarioController.getUsuarioAutenticado());
        carritoDAO.crear(carrito);

        System.out.println(">>> DAO: Carrito guardado con código " + carrito.getCodigo());

        itemsTemporales.clear(); // ✅ LIMPIA LOS PRODUCTOS TEMPORALES DESPUÉS DE GUARDAR
    }


    public void imprimirTodosCarritosDebug() {
        System.out.println(">>> LISTA DE CARRITOS");

        List<Carrito> carritos = carritoDAO.listarTodos();

        if (carritos.isEmpty()) {
            System.out.println("⚠️ No hay carritos registrados.");
            return;
        }

        for (Carrito c : carritos) {
            String usuario = (c.getUsuario() != null) ? c.getUsuario().getUsername() : "desconocido";
            int cantidadProductos = (c.obtenerItems() != null) ? c.obtenerItems().size() : 0;

            System.out.println("- Código: " + c.getCodigo()
                    + " | Usuario: " + usuario
                    + " | Productos: " + cantidadProductos);
        }
    }


    // Buscar un carrito por código
    public Carrito buscarCarrito(int codigoCarrito) {
        return carritoDAO.buscarPorCodigo(codigoCarrito);
    }

    // Eliminar un carrito
    public void eliminarCarrito(int codigoCarrito) {
        carritoDAO.eliminarPorCodigo(codigoCarrito);
    }

    // Listar todos los carritos (solo admin)
    public List<Carrito> listarTodosCarritos() {
        Usuario usuario = usuarioController.getUsuarioAutenticado();
        System.out.println(">>> Usuario autenticado: " + (usuario != null ? usuario.getUsername() : "null"));
        if (usuario != null && usuario.getRol() == Rol.ADMINISTRADOR) {
            System.out.println(">>> Retornando todos los carritos...");
            return carritoDAO.listarTodos();
        }
        System.out.println(">>> Usuario no autorizado para ver todos los carritos.");
        return null;
    }

    // Listar carritos del usuario actual
    public List<Carrito> listarMisCarritos() {
        Usuario usuario = usuarioController.getUsuarioAutenticado();
        if (usuario != null && usuario.getRol() == Rol.ADMINISTRADOR) {
            return carritoDAO.listarTodos();
        }
        return null;
    }

    public List<Carrito> listarCarritosSinFiltro() {
        return carritoDAO.listarTodos();
    }


    // Listar carritos de un usuario específico
    public List<Carrito> listarMisCarritos(Usuario usuario) {
        return carritoDAO.listarTodos().stream()
                .filter(c -> c.getUsuario() != null && c.getUsuario().getUsername().equals(usuario.getUsername()))
                .toList();
    }

    // Buscar producto por código
    public Producto buscarProductoPorCodigo(int codigo) {
        return productoDAO.buscarPorCodigo(codigo);
    }

    // Modificar cantidad de un producto en un carrito ya guardado
    public void modificarCantidad(Carrito carrito, int codigoProducto, int nuevaCantidad) {
        carrito.actualizarCantidadProducto(codigoProducto, nuevaCantidad);
    }
}
